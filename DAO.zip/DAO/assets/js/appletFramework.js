$(function() {
	$.getJSON('/assets/js/appReg.json', function(data) {
		console.log(data);
		$.each(data.app, function(i, applet) {
			console.log(applet);
var appContent = '<object height="380px" type="text/html" data="'+ applet.appFile +'" ></object>';
var appletFrame =
'<div class="col-xl-4 col-sm-6">' + 
'' + 
'<div class="card mb-3">' + 
'' + 
'<div class="card-header card-header-inverse">' + 
'<h4 class="card-header-title">' + 
applet.name + 
'</h4>' + 
'<div class="card-header-btn">' + 
'<a href="#" data-toggle="card-expand" class="btn btn-success"><i class="fa fa-expand"></i></a>' + 
'<a href="#" data-toggle="card-refresh" class="btn btn-warning"><i class="fa fa-redo"></i></a>' + 
'<a href="#" data-toggle="card-remove" class="btn btn-danger"><i class="fa fa-trash-alt"></i></a>' + 
'</div>' + 
'</div>' + 
appContent
'</div>' + 
'</div>';
$("#testAPP").append(appletFrame);
     });

   });

});