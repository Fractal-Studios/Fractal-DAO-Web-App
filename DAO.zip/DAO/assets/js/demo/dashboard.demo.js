var handleNotification = function() {
	$.notification({
		title: 'Logged-in!',
		content: 'Welcome to Fractal DAO.',
		icon: 'fa fa-door-open',
		iconClass: 'bg-gradient-blue-indigo text-white'
	});
};


/* Controller
------------------------------------------------ */
$(document).ready(function() {
	handleNotification();
});